a = int(input("Enter the first number:"))
b = int(input("Enter the second number:"))
c = 0 
for i in range (a , b + 1):
    c = c + i 
    i = i + 1 
print("sum is : ", c)
