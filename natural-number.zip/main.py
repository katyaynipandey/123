a = int (input("Enter the number : "))
i=1 
print("The natural numbers between 1 and {0} are : ". format (a))

while (i <= a):
    print ( i , end = '')
    i = i + 1