a = int (input("Enter any number : "))
b = 0
 
while (a > 0):
    b = b + a
    a = a - 1 
print ("Sum is :", b)
