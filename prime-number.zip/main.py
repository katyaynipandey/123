a = int (input ("Enter the number: "))
if (a == 2):
    print (a , "is a prime number.")
elif a > 0 :
    
    for i in range (2 , int(a/2)+1):
        if (a % i) == 0 :
            print (a , "is not a prime number.")
        else:
            print (a , "is a prime number.")
else: 
    print(a , "is a prime number.") 